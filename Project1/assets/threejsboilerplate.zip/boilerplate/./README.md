[boilerplate for three.js](https://github.com/jeromeetienne/threejsboilerplate)
is a template to get you started. You download it and modify it until it fits your needs.
It is a fast way to start a clean project with [three.js](https://github.com/mrdoob/three.js/).
It avoids repetitive tasks, following DRY principles.
It includes various good practices and compatibilities features.
More details [here](http://learningthreejs.com/blog/2011/12/20/boilerplate-for-three-js/).

# Get Started
```
git clone https://github.com/jeromeetienne/threejsboilerplate.git
```

And start updating ```index.html``` until it fits yours need.
